$(document).ready(function(){

	var s = skrollr.init({

			smoothScrolling: false,
			forceHeight: true
	});
});